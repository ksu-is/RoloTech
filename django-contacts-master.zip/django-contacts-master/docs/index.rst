.. _index:
.. Django Contacts documentation master file, created by
   sphinx-quickstart on Thu May 28 21:54:45 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Django Contacts
===============

Contents:

.. toctree::
	:maxdepth: 2
	
	license

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`