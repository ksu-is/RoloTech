'A Django address book application.'
VERSION = (0, 6, 0)
__version__ = ".".join(map(str, VERSION))
__url__ = 'http://github.com/myles/django-contacts'
__author__ = 'Myles Braithwaite'
__email__ = 'me@mylesbraithwaite.com'
__license__ = 'BSD License'
